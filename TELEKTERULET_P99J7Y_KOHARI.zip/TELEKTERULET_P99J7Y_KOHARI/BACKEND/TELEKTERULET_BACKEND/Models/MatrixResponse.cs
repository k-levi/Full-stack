﻿namespace TELEKTERULET_BACKEND.Models
{
    public class MatrixResponse
    {
        public double[][] Matrix { get; set; }
        public double Epsilon { get; set; }
        public List<(int, int)> LargestArea { get; set; }
    }
}
