﻿namespace TELEKTERULET_BACKEND.Models
{
    public class MatrixRequest
    {
        public double[][] Matrix { get; set; }
        public double Epsilon { get; set; }
    }
}