﻿using TELEKTERULET_BACKEND.Models;

namespace TELEKTERULET_BACKEND.Services
{
    public class MatrixResult
    {
        public List<int[]> LargestAreaIndices { get; set; } = new List<int[]>();
        public int AreaSize { get; set; }
    }
    public class MatrixService
    {
        private readonly int[] dr = { -1, -1, -1, 0, 0, 1, 1, 1 };
        private readonly int[] dc = { -1, 0, 1, -1, 1, -1, 0, 1 };

        public MatrixResult FindLargestConnectedArea(double[][] matrix, double epsilon)
        {
            if (matrix == null || matrix.Length == 0)
                return new MatrixResult();

            int rows = matrix.Length;
            int cols = matrix[0].Length;
            bool[][] visited = new bool[rows][];
            for (int i = 0; i < rows; i++)
            {
                visited[i] = new bool[cols];
            }

            MatrixResult result = new MatrixResult();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (!visited[i][j])
                    {
                        List<int[]> currentArea = new List<int[]>();
                        int size = DFS(matrix, i, j, visited, currentArea, epsilon);

                        if (size > result.AreaSize)
                        {
                            result.AreaSize = size;
                            result.LargestAreaIndices = currentArea;
                        }
                    }
                }
            }

            return result;
        }

        private int DFS(double[][] matrix, int row, int col, bool[][] visited, List<int[]> currentArea, double epsilon)
        {
            int rows = matrix.Length;
            int cols = matrix[0].Length;

            if (row < 0 || col < 0 || row >= rows || col >= cols || visited[row][col])
                return 0;

            visited[row][col] = true;
            double baseValue = matrix[row][col];
            currentArea.Add(new int[] { row, col });
            int size = 1;

            for (int i = 0; i < 8; i++)
            {
                int newRow = row + dr[i];
                int newCol = col + dc[i];

                if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols &&
                    !visited[newRow][newCol] &&
                    Math.Abs(matrix[newRow][newCol] - baseValue) <= epsilon)
                {
                    size += DFS(matrix, newRow, newCol, visited, currentArea, epsilon);
                }
            }

            return size;
        }
    }

}
