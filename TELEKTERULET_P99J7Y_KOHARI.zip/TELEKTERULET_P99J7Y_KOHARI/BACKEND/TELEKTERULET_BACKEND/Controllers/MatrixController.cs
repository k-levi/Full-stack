﻿using Microsoft.AspNetCore.Mvc;
using TELEKTERULET_BACKEND.Models;
using TELEKTERULET_BACKEND.Services;

namespace TELEKTERULET_BACKEND.Controllers
{
    [ApiController]
    [Route("api/matrix")]
    public class MatrixController : ControllerBase
    {
        private readonly MatrixService _matrixService;

        public MatrixController(MatrixService matrixService)
        {
            _matrixService = matrixService;
        }

        [HttpPost]
        public IActionResult ProcessMatrix([FromBody] MatrixRequest request)
        {
            if (request == null || request.Matrix == null)
            {
                return BadRequest("Érvénytelen bemenet.");
            }

            var result = _matrixService.FindLargestConnectedArea(request.Matrix, request.Epsilon);
            return Ok(new
            {
                Matrix = request.Matrix,
                Epsilon = request.Epsilon,
                LargestArea = result.LargestAreaIndices,
                AreaSize = result.AreaSize
            });
        }
    }
}
